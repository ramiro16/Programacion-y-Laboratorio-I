#include <stdio.h>
#include <stdlib.h>

int main()
{
    int vector[5]= {5,10,15,98,7};
    int i, j;
    int auxInt;

  for(i=0; i<4; i++)//VERDE
    {
        for(j=i+1; j<5; j++)//AMARILLA
        {
            if(vector[i]>vector[j])
            {
               auxInt = vector[i];
               vector[i] = vector[j];
               vector[j] = auxInt;
            }
        }
    }

    for(i=0; i<5; i++)
    {
        printf("%d\n", vector[i]);
    }



    return 0;
}
