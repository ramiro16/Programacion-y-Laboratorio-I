#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

int ignora(char[],char[]);


int main()
{
    char palabra[15], palabra2[15]="chau";
    char buffer[1024];
    int cantidad;
    int comp;

    printf("Ingrese una palabra: ");
    fflush(stdin);
    gets(buffer);

    while(strlen(buffer)>14)
    {
        printf("Error!! Reingrese una palabra: ");
        fflush(stdin);
        gets(buffer);
    }

    strcpy(palabra, buffer);

    //strupr(palabra);


    comp=ignora("CHAU",palabra);

    strcat(palabra2, palabra);

    printf("Resultado de la comparacion: %d\n", comp);
    printf("La palabra que ingreso es: %s", palabra2);

    return 0;
}

int ignora(char cadena1[], char cadena2[])
{
    char c1[1000], c2[1000];
    int comp;
    strcpy(c1,cadena1);
    strcpy(c2,cadena2);

    strlwr(c1);
    strlwr(c2);

    comp = strcmp(c1,c2);

    return comp;

}
