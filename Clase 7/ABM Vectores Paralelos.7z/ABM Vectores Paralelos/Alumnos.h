
void altaAlumno(int[], char[][50], int[], int[], float[], int);
void mostrarAlumnos(int[], char[][50], int[], int[], float[], int);
void ordenarAlumnos(int[], char[][50], int[], int[], float[], int);
void modificarAlumno(int[], char[][50], int[], int[], float[], int);
void eliminarAlumno(int legajo[], char nombre[][50], int nota1[], int nota2[], float promedio[], int tam);
void mostrar(int, char[], int, int, float);
